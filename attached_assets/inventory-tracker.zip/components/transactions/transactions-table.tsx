"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

const transactionsData = [
  {
    id: "T12345",
    user: {
      name: "John Doe",
      email: "john@example.com",
    },
    item: "Elastic Bandage",
    facility: "Main Clinic",
    type: "use",
    quantity: 5,
    timestamp: "2023-11-15T14:30:00Z",
  },
  {
    id: "T12346",
    user: {
      name: "Jane Smith",
      email: "jane@example.com",
    },
    item: "Ankle Brace",
    facility: "Physical Therapy",
    type: "restock",
    quantity: 10,
    timestamp: "2023-11-15T13:45:00Z",
  },
  {
    id: "T12347",
    user: {
      name: "Mike Johnson",
      email: "mike@example.com",
    },
    item: "Ice Pack",
    facility: "Sports Medicine",
    type: "transfer",
    quantity: 8,
    timestamp: "2023-11-15T11:20:00Z",
  },
  {
    id: "T12348",
    user: {
      name: "Sarah Williams",
      email: "sarah@example.com",
    },
    item: "Gauze Pads",
    facility: "Emergency",
    type: "use",
    quantity: 15,
    timestamp: "2023-11-15T10:05:00Z",
  },
  {
    id: "T12349",
    user: {
      name: "David Brown",
      email: "david@example.com",
    },
    item: "Athletic Tape",
    facility: "Training Room",
    type: "restock",
    quantity: 20,
    timestamp: "2023-11-15T09:30:00Z",
  },
  {
    id: "T12350",
    user: {
      name: "Emily Davis",
      email: "emily@example.com",
    },
    item: "Knee Brace",
    facility: "Main Clinic",
    type: "use",
    quantity: 2,
    timestamp: "2023-11-14T16:45:00Z",
  },
  {
    id: "T12351",
    user: {
      name: "Michael Wilson",
      email: "michael@example.com",
    },
    item: "Compression Sleeve",
    facility: "Physical Therapy",
    type: "transfer",
    quantity: 5,
    timestamp: "2023-11-14T14:20:00Z",
  },
  {
    id: "T12352",
    user: {
      name: "Jessica Taylor",
      email: "jessica@example.com",
    },
    item: "Bandage Scissors",
    facility: "Emergency",
    type: "restock",
    quantity: 8,
    timestamp: "2023-11-14T11:10:00Z",
  },
]

export function TransactionsTable() {
  const [transactions, setTransactions] = useState(transactionsData)

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Transaction ID</TableHead>
            <TableHead>User</TableHead>
            <TableHead>Item</TableHead>
            <TableHead>Facility</TableHead>
            <TableHead>Type</TableHead>
            <TableHead className="text-right">Quantity</TableHead>
            <TableHead className="text-right">Date & Time</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((transaction) => (
            <TableRow key={transaction.id}>
              <TableCell className="font-medium">{transaction.id}</TableCell>
              <TableCell>
                <div className="flex flex-col">
                  <span>{transaction.user.name}</span>
                  <span className="text-xs text-muted-foreground">{transaction.user.email}</span>
                </div>
              </TableCell>
              <TableCell>{transaction.item}</TableCell>
              <TableCell>{transaction.facility}</TableCell>
              <TableCell>
                <Badge variant={getTransactionTypeVariant(transaction.type)}>
                  {formatTransactionType(transaction.type)}
                </Badge>
              </TableCell>
              <TableCell className="text-right">{transaction.quantity}</TableCell>
              <TableCell className="text-right">{formatDate(transaction.timestamp)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

function getTransactionTypeVariant(type) {
  switch (type) {
    case "use":
      return "destructive"
    case "restock":
      return "success"
    case "transfer":
      return "secondary"
    default:
      return "default"
  }
}

function formatTransactionType(type) {
  return type.charAt(0).toUpperCase() + type.slice(1)
}

function formatDate(dateString) {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    hour12: true,
  }).format(date)
}

