"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { EditFacilityDialog } from "@/components/facilities/edit-facility-dialog"
import { MoreHorizontal, Package } from "lucide-react"

const facilitiesData = [
  {
    id: 1,
    facility_name: "Main Clinic",
    location: "Building A, Floor 1",
    items_count: 245,
  },
  {
    id: 2,
    facility_name: "Physical Therapy",
    location: "Building B, Floor 2",
    items_count: 178,
  },
  {
    id: 3,
    facility_name: "Sports Medicine",
    location: "Building A, Floor 3",
    items_count: 203,
  },
  {
    id: 4,
    facility_name: "Emergency",
    location: "Building C, Floor 1",
    items_count: 312,
  },
  {
    id: 5,
    facility_name: "Training Room",
    location: "Building D, Floor 1",
    items_count: 156,
  },
]

export function FacilitiesTable() {
  const [facilities, setFacilities] = useState(facilitiesData)

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Facility Name</TableHead>
            <TableHead>Location</TableHead>
            <TableHead className="text-right">Items Count</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {facilities.map((facility) => (
            <TableRow key={facility.id}>
              <TableCell className="font-medium">{facility.facility_name}</TableCell>
              <TableCell>{facility.location}</TableCell>
              <TableCell className="text-right">{facility.items_count}</TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <Package className="mr-2 h-4 w-4" />
                      <span>View Inventory</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <EditFacilityDialog facility={facility}>
                      <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Edit Facility</DropdownMenuItem>
                    </EditFacilityDialog>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

