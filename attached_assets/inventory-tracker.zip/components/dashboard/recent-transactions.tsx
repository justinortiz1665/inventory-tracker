import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const transactions = [
  {
    id: "T12345",
    user: {
      name: "John Doe",
      email: "john@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "JD",
    },
    item: "Elastic Bandage",
    facility: "Main Clinic",
    type: "use",
    quantity: 5,
    timestamp: "2023-11-15T14:30:00Z",
  },
  {
    id: "T12346",
    user: {
      name: "Jane Smith",
      email: "jane@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "JS",
    },
    item: "Ankle Brace",
    facility: "Physical Therapy",
    type: "restock",
    quantity: 10,
    timestamp: "2023-11-15T13:45:00Z",
  },
  {
    id: "T12347",
    user: {
      name: "Mike Johnson",
      email: "mike@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "MJ",
    },
    item: "Ice Pack",
    facility: "Sports Medicine",
    type: "transfer",
    quantity: 8,
    timestamp: "2023-11-15T11:20:00Z",
  },
  {
    id: "T12348",
    user: {
      name: "Sarah Williams",
      email: "sarah@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "SW",
    },
    item: "Gauze Pads",
    facility: "Emergency",
    type: "use",
    quantity: 15,
    timestamp: "2023-11-15T10:05:00Z",
  },
  {
    id: "T12349",
    user: {
      name: "David Brown",
      email: "david@example.com",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "DB",
    },
    item: "Athletic Tape",
    facility: "Training Room",
    type: "restock",
    quantity: 20,
    timestamp: "2023-11-15T09:30:00Z",
  },
]

export function RecentTransactions() {
  return (
    <div className="space-y-4">
      {transactions.map((transaction) => (
        <div key={transaction.id} className="flex items-center gap-4">
          <Avatar className="h-9 w-9">
            <AvatarImage src={transaction.user.avatar} alt={transaction.user.name} />
            <AvatarFallback>{transaction.user.initials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{transaction.item}</p>
            <p className="text-sm text-muted-foreground">
              {transaction.user.name} • {transaction.facility}
            </p>
          </div>
          <Badge variant={getBadgeVariant(transaction.type)}>
            {formatTransactionType(transaction.type)} • {transaction.quantity}
          </Badge>
        </div>
      ))}
    </div>
  )
}

function getBadgeVariant(type: string) {
  switch (type) {
    case "use":
      return "destructive"
    case "restock":
      return "success"
    case "transfer":
      return "secondary"
    default:
      return "default"
  }
}

function formatTransactionType(type: string) {
  return type.charAt(0).toUpperCase() + type.slice(1)
}

