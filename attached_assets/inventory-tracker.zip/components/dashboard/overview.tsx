"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts"

const data = [
  {
    name: "Jan",
    total: 234,
  },
  {
    name: "Feb",
    total: 345,
  },
  {
    name: "Mar",
    total: 289,
  },
  {
    name: "Apr",
    total: 403,
  },
  {
    name: "May",
    total: 356,
  },
  {
    name: "Jun",
    total: 410,
  },
  {
    name: "Jul",
    total: 321,
  },
  {
    name: "Aug",
    total: 287,
  },
  {
    name: "Sep",
    total: 346,
  },
  {
    name: "Oct",
    total: 401,
  },
  {
    name: "Nov",
    total: 378,
  },
  {
    name: "Dec",
    total: 425,
  },
]

export function Overview() {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}`} />
        <Tooltip />
        <Bar dataKey="total" fill="currentColor" radius={[4, 4, 0, 0]} className="fill-primary" />
      </BarChart>
    </ResponsiveContainer>
  )
}

