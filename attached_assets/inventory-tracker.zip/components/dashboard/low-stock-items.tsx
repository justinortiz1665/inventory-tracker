import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowUpRight } from "lucide-react"

const lowStockItems = [
  {
    id: "I12345",
    name: "Elastic Bandage",
    category: "Rehab",
    quantity: 5,
    threshold: 10,
    status: "critical",
  },
  {
    id: "I12346",
    name: "Ice Pack",
    category: "First-Aid/Gen Med",
    quantity: 8,
    threshold: 15,
    status: "warning",
  },
  {
    id: "I12347",
    name: "Athletic Tape",
    category: "Tape",
    quantity: 3,
    threshold: 10,
    status: "critical",
  },
  {
    id: "I12348",
    name: "Ankle Brace (Medium)",
    category: "Bracing",
    quantity: 4,
    threshold: 5,
    status: "warning",
  },
  {
    id: "I12349",
    name: "Gauze Pads",
    category: "First-Aid/Gen Med",
    quantity: 12,
    threshold: 20,
    status: "warning",
  },
]

export function LowStockItems() {
  return (
    <div className="space-y-4">
      {lowStockItems.map((item) => (
        <div key={item.id} className="flex items-center justify-between gap-4">
          <div className="space-y-1">
            <p className="text-sm font-medium leading-none">{item.name}</p>
            <p className="text-xs text-muted-foreground">{item.category}</p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={item.status === "critical" ? "destructive" : "outline"}>
              {item.quantity}/{item.threshold}
            </Badge>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <ArrowUpRight className="h-4 w-4" />
              <span className="sr-only">View details</span>
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}

