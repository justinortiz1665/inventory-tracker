"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { BarChart3, Package, Building2, History, Users, Settings, Menu } from "lucide-react"

interface NavItem {
  title: string
  href: string
  icon: React.ReactNode
  admin?: boolean
}

const navItems: NavItem[] = [
  {
    title: "Dashboard",
    href: "/",
    icon: <BarChart3 className="h-5 w-5" />,
  },
  {
    title: "Inventory",
    href: "/inventory",
    icon: <Package className="h-5 w-5" />,
  },
  {
    title: "Facilities",
    href: "/facilities",
    icon: <Building2 className="h-5 w-5" />,
  },
  {
    title: "Transactions",
    href: "/transactions",
    icon: <History className="h-5 w-5" />,
  },
  {
    title: "Users",
    href: "/users",
    icon: <Users className="h-5 w-5" />,
    admin: true,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: <Settings className="h-5 w-5" />,
  },
]

export default function Sidebar() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const isAdmin = true // This would be determined by your auth system

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild className="lg:hidden">
          <Button variant="outline" size="icon" className="absolute left-4 top-4 z-40">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0">
          <div className="space-y-4 py-4">
            <div className="px-3 py-2">
              <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">Inventory Tracker</h2>
              <div className="space-y-1">
                <Nav items={navItems} pathname={pathname} isAdmin={isAdmin} />
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
      <aside className="hidden lg:block border-r bg-gray-100/40 dark:bg-gray-800/40">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-6">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <Package className="h-6 w-6" />
              <span>Inventory Tracker</span>
            </Link>
          </div>
          <div className="flex-1 overflow-auto py-2">
            <Nav items={navItems} pathname={pathname} isAdmin={isAdmin} />
          </div>
        </div>
      </aside>
    </>
  )
}

interface NavProps {
  items: NavItem[]
  pathname: string
  isAdmin: boolean
}

function Nav({ items, pathname, isAdmin }: NavProps) {
  return (
    <ScrollArea className="h-[calc(100vh-8rem)]">
      <div className="px-4 py-2">
        {items.map((item) => {
          if (item.admin && !isAdmin) return null
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors",
                pathname === item.href ? "bg-accent text-accent-foreground" : "transparent",
              )}
            >
              {item.icon}
              {item.title}
            </Link>
          )
        })}
      </div>
    </ScrollArea>
  )
}

