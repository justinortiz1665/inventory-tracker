"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { EditItemDialog } from "@/components/inventory/edit-item-dialog"
import { MoreHorizontal, Plus, Minus, ArrowLeftRight } from "lucide-react"

const inventoryData = [
  {
    id: 1,
    item_number: "I12345",
    item_name: "Elastic Bandage",
    category: "Rehab",
    vendor: "MedSupply Co.",
    quantity: 25,
    unit: "roll",
    min_threshold: 10,
    max_threshold: 50,
    price: 4.99,
  },
  {
    id: 2,
    item_number: "I12346",
    item_name: "Ice Pack",
    category: "First-Aid/Gen Med",
    vendor: "CoolTherapy Inc.",
    quantity: 18,
    unit: "pack",
    min_threshold: 15,
    max_threshold: 40,
    price: 7.5,
  },
  {
    id: 3,
    item_number: "I12347",
    item_name: "Athletic Tape",
    category: "Tape",
    vendor: "SportsMed",
    quantity: 8,
    unit: "roll",
    min_threshold: 10,
    max_threshold: 30,
    price: 3.25,
  },
  {
    id: 4,
    item_number: "I12348",
    item_name: "Ankle Brace (Medium)",
    category: "Bracing",
    vendor: "SupportWear",
    quantity: 12,
    unit: "brace",
    min_threshold: 5,
    max_threshold: 20,
    price: 24.99,
  },
  {
    id: 5,
    item_number: "I12349",
    item_name: "Gauze Pads",
    category: "First-Aid/Gen Med",
    vendor: "MedSupply Co.",
    quantity: 42,
    unit: "box",
    min_threshold: 20,
    max_threshold: 60,
    price: 8.75,
  },
]

export function InventoryTable() {
  const [inventory, setInventory] = useState(inventoryData)

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Item #</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Vendor</TableHead>
            <TableHead className="text-right">Quantity</TableHead>
            <TableHead className="text-right">Price</TableHead>
            <TableHead className="text-right">Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {inventory.map((item) => (
            <TableRow key={item.id}>
              <TableCell className="font-medium">{item.item_number}</TableCell>
              <TableCell>{item.item_name}</TableCell>
              <TableCell>{item.category}</TableCell>
              <TableCell>{item.vendor}</TableCell>
              <TableCell className="text-right">
                {item.quantity} {item.unit}
              </TableCell>
              <TableCell className="text-right">${item.price.toFixed(2)}</TableCell>
              <TableCell className="text-right">
                <Badge variant={getStockStatusVariant(item)}>{getStockStatus(item)}</Badge>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <Plus className="mr-2 h-4 w-4" />
                      <span>Add Stock</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Minus className="mr-2 h-4 w-4" />
                      <span>Remove Stock</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <ArrowLeftRight className="mr-2 h-4 w-4" />
                      <span>Transfer</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <EditItemDialog item={item}>
                      <DropdownMenuItem onSelect={(e) => e.preventDefault()}>Edit Item</DropdownMenuItem>
                    </EditItemDialog>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

function getStockStatus(item) {
  if (item.quantity <= item.min_threshold) {
    return "Low Stock"
  } else if (item.quantity >= item.max_threshold) {
    return "Overstocked"
  } else {
    return "In Stock"
  }
}

function getStockStatusVariant(item) {
  if (item.quantity <= item.min_threshold) {
    return "destructive"
  } else if (item.quantity >= item.max_threshold) {
    return "warning"
  } else {
    return "success"
  }
}

