"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function AddInventoryDialog({ children }) {
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({
    item_number: "",
    item_name: "",
    category: "",
    vendor: "",
    quantity: "",
    unit: "",
    min_threshold: "",
    max_threshold: "",
    price: "",
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Here you would typically send the data to your API
    console.log("Form submitted:", formData)
    setOpen(false)
    // Reset form
    setFormData({
      item_number: "",
      item_name: "",
      category: "",
      vendor: "",
      quantity: "",
      unit: "",
      min_threshold: "",
      max_threshold: "",
      price: "",
    })
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Add New Inventory Item</DialogTitle>
            <DialogDescription>Fill in the details for the new inventory item.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="item_number">Item Number</Label>
                <Input
                  id="item_number"
                  name="item_number"
                  value={formData.item_number}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="item_name">Item Name</Label>
                <Input id="item_name" name="item_name" value={formData.item_name} onChange={handleChange} required />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={formData.category} onValueChange={(value) => handleSelectChange("category", value)}>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rehab">Rehab</SelectItem>
                    <SelectItem value="emergency">Emergency</SelectItem>
                    <SelectItem value="first-aid">First-Aid/Gen Med</SelectItem>
                    <SelectItem value="bracing">Bracing</SelectItem>
                    <SelectItem value="tape">Tape</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vendor">Vendor</Label>
                <Input id="vendor" name="vendor" value={formData.vendor} onChange={handleChange} />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  name="quantity"
                  type="number"
                  min="0"
                  value={formData.quantity}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unit">Unit</Label>
                <Input id="unit" name="unit" value={formData.unit} onChange={handleChange} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="price">Price ($)</Label>
                <Input
                  id="price"
                  name="price"
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.price}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="min_threshold">Min Threshold</Label>
                <Input
                  id="min_threshold"
                  name="min_threshold"
                  type="number"
                  min="0"
                  value={formData.min_threshold}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max_threshold">Max Threshold</Label>
                <Input
                  id="max_threshold"
                  name="max_threshold"
                  type="number"
                  min="0"
                  value={formData.max_threshold}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit">Add Item</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

