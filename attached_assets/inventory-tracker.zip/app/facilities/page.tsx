import { FacilitiesTable } from "@/components/facilities/facilities-table"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { AddFacilityDialog } from "@/components/facilities/add-facility-dialog"

export default function FacilitiesPage() {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Facilities Management</h1>
        <AddFacilityDialog>
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Facility
          </Button>
        </AddFacilityDialog>
      </div>
      <FacilitiesTable />
    </div>
  )
}

