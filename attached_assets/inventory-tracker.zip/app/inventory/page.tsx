import { InventoryTable } from "@/components/inventory/inventory-table"
import { InventoryFilters } from "@/components/inventory/inventory-filters"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { AddInventoryDialog } from "@/components/inventory/add-inventory-dialog"

export default function InventoryPage() {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Inventory Management</h1>
        <AddInventoryDialog>
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Item
          </Button>
        </AddInventoryDialog>
      </div>
      <InventoryFilters />
      <InventoryTable />
    </div>
  )
}

